<template>
  <div class="container">
    <h1>Juego del Gato</h1>
    <div class="area-juego">
      <div id="bloque_0" class="bloque" @click="draw(0)">{{ content[0] }}</div>
      <div id="bloque_1" class="bloque" @click="draw(1)">{{ content[1] }}</div>
      <div id="bloque_2" class="bloque" @click="draw(2)">{{ content[2] }}</div>
      <div id="bloque_3" class="bloque" @click="draw(3)">{{ content[3] }}</div>
      <div id="bloque_4" class="bloque" @click="draw(4)">{{ content[4] }}</div>
      <div id="bloque_5" class="bloque" @click="draw(5)">{{ content[5] }}</div>
      <div id="bloque_6" class="bloque" @click="draw(6)">{{ content[6] }}</div>
      <div id="bloque_7" class="bloque" @click="draw(7)">{{ content[7] }}</div>
      <div id="bloque_8" class="bloque" @click="draw(8)">{{ content[8] }}</div>
    </div>
    <h2 id="ganador" v-if="isOver">Ganador es {{ ganador }}</h2>
    <h2 v-if="isMarcador">Juego marcado</h2>
    <button @click="resetTablero()" v-if="isOver || isMarcador">
      Reestablecer tablero
    </button>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {},
  data() {
    return {
      content: ["", "", "", "", "", "", "", ""],
      turn: true,
      isOver: false,
      ganador: null,
      isMarcador: false,
    };
  },
  methods: {
    draw(index) {
      if (this.turn) {
        this.content[index] = "X";
      } else {
        this.content[index] = "O";
      }

      this.turn = !this.turn;
      this.calcularGanador();
      this.calcularMarcador();
    },

    calcularGanador() {
      console.log("aqui");
      const GANADOR_CONDITIONS = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],

        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],

        [0, 4, 8],
        [2, 4, 6],
      ];

      for (let i = 0; i < GANADOR_CONDITIONS.length; i++) {
        let primertIndex = GANADOR_CONDITIONS[i][0];
        let segundoIndex = GANADOR_CONDITIONS[i][1];
        let tercerIndex = GANADOR_CONDITIONS[i][2];
        if (
          this.content[primertIndex] == this.content[segundoIndex] &&
          this.content[primertIndex] == this.content[tercerIndex] &&
          this.content[primertIndex] != ""
        ) {
          this.isOver = true;
          this.ganador = this.content[primertIndex];
        }
      }
    },

    calcularMarcador() {
      for (let i = 0; i <= 8; i++) {
        if (this.content[i] == "") {
          return;
        }
      }
      this.isMarcador = true;
    },
    resetTablero() {
      for (let i = 0; i <= 8; i++) {
        this.content[i] = "";
        this.isOver = false;
        this.winner = null;
        this.isMarcador = false;
      }
    },
  },
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: Arial, Helvetica, sans-serif;
}
.container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #eee;
}
h1 {
  font-size: 5rem;
  margin-bottom: 0.5em;
}
h2 {
  margin-top: 1em;
  font-size: 2rem;
  margin-bottom: 0.5em;
}
.area-juego {
  display: grid;
  width: 300px;
  height: 300px;
  grid-template-columns: auto auto auto;
}
.bloque {
  display: flex;
  width: 100px;
  height: 100px;
  align-items: center;
  justify-content: center;
  font-size: 3rem;
  font-weight: bold;
  border: 3px solid black;
  transition: background 0.2s ease-in-out;
}
.bloque:hover {
  cursor: pointer;
  background: #0ff30f;
}
.occupied:hover {
  background: #ff3a3a;
}
.win {
  background: #0ff30f;
}
.win:hover {
  background: #0ff30f;
}
#bloque_0,
#bloque_1,
#bloque_2 {
  border-top: none;
}
#bloque_0,
#bloque_3,
#bloque_6 {
  border-left: none;
}
#bloque_6,
#bloque_7,
#bloque_8 {
  border-bottom: none;
}
#bloque_2,
#bloque_5,
#bloque_8 {
  border-right: none;
}
button {
  outline: none;
  border: 4px solid green;
  padding: 10px 20px;
  font-size: 1rem;
  font-weight: bold;
  background: none;
  transition: all 0.2s ease-in-out;
}
button:hover {
  cursor: pointer;
  background: green;
  color: white;
}
.playerWin {
  color: green;
}
.computerWin {
  color: red;
}
.draw {
  color: orangered;
}
@media only screen and (max-width: 600px) {
  h1 {
    font-size: 3rem;
    margin-bottom: 0.5em;
  }
  h2 {
    margin-top: 1em;
    font-size: 1.3rem;
  }
}
</style>
